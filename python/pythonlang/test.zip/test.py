a = int(input("Enter your age: "))
print("your age is:", a)
print(a>18)
print(a<18)
print(a>=18)
print(a<=18)
print(a==18)
if(a>18):
    print("you can drive")
else:
    print("you cannot drive")