# nstAppTemplate

A Flutter project that aims to welcome the "new student" to a new school.

# Contributing

Before contributing please read the [app contributing document](https://github.com/hackforla/new-schools-today/blob/master/nstAppTemplate/CONTRIBUTING.md)
