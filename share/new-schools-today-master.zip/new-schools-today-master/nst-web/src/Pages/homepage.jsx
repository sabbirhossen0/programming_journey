import React from 'react'
import Typography from '@material-ui/core/Typography';

export default function HomePage(){
    return (
        <div>
            <Typography>New Schools Today</Typography>
        </div>
    );
}