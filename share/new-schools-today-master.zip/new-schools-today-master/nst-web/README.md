### General

New Schools Today's website is a platform where students can publish their school's app. Students will enter data, chose relevant features, and customize its style. 

We are using React with the Material-UI framework.

### Contributing

To contribute to our website, please read our [contributing document](https://github.com/hackforla/new-schools-today/blob/master/nst-web/CONTRIBUTING.md). 

When contributing, please add components to the components folder and pages to the pages folder; Limit each pull request (PR) to a single feature. 

