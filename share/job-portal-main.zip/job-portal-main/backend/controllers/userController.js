import {v2 as cloudinary} from "cloudinary";
import {catchAsyncErrors} from "../middlewares/catchAsyncErrors.js";
import ErrorHandler from "../middlewares/error.js";
import {User} from "../models/userSchema.js";
import {sendToken} from "../utils/jwtToken.js";


export const register = catchAsyncErrors(async(req, res, next) => {
    try {
        const {body:{
            name,
            email,
            phone,
            address,
            password,
            role,
            firstNiche,
            secondNiche,
            thirdNiche,
            coverLetter,
            }} = req;

            if(!name || !email || !phone || !address || !password || !role){
                return next(new ErrorHandler("All field are required.", 400));
            }

            if(role === "Job Seeker" && (!firstNiche || !secondNiche || !thirdNiche)){
                return next(new ErrorHandler("Please provide your preferred niches.", 400));
            }

            const existingUser = await User.findOne({email});

            if(existingUser){
                return next(new ErrorHandler("Email already registerd.", 400));
            }

            const userData = {
                name,
                email,
                phone,
                address,
                password,
                role,
                niches:{
                    firstNiche,
                    secondNiche,
                    thirdNiche,
                },
                coverLetter,
            }

            if(req.files && req.files.resume){
                const {resume} = req.files;
                if(resume){
                    try {
                        const cloudinaryRespose = await cloudinary.uploader.upload(resume.tempFilePath,{
                            folder:"Job_Seeker_Resume"
                        });
                        if(!cloudinaryRespose || cloudinaryRespose.error){
                            return next( new ErrorHandler("Failed to upload resume to cloud", 500));
                        };
                        userData.resume = {
                            public_id: cloudinaryRespose.public_id,
                            url: cloudinaryRespose.secure_url,
                        };
                    } catch (error) {
                        return next(new ErrorHandler("Failed to upload resume",500));
                    }
                }
            }
        const user = await User.create(userData);
        sendToken(user, 201, res, "User registered.");
    } catch (error) {
        next(error);
    }
});

export const login = catchAsyncErrors(async(req, res, next) =>{
    const {role, email, password} = req.body;

    if(!role || !email || !password){
        return next(new ErrorHandler("Role, Email and Password are required.",400));
    };

    const user = await User.findOne({email}).select("+password");

    if(!user){
       return next(new ErrorHandler("Invalied Email", 400));
    };
    
    const isPasswordMatched = await user.comparedPassword(password);

    if(!isPasswordMatched){
        return next(new ErrorHandler("Invalied Password", 400));
    };

    if(user.role !== role){
        return next(new ErrorHandler("Invalied Role", 400));
    };

    sendToken(user, 201, res, "User logged in successfully.");
});

export const logout = catchAsyncErrors(async (req, res, next) =>{
    res.status(200)
            .cookie("token","",{
                expires: new Date(Date.now()),
                httpOnly:true,
            })
            .json({
                success: true,
                message: "User logged out."
            });
});

export const getUser = catchAsyncErrors(async (req, res, next) => {
    const user = req.user;
    res.status(200).json({
        success: true,
        user,
    });
});

export const updateUser = catchAsyncErrors(async (req, res, next) => {
    const {
        body:{
            name,
            email,
            phone,
            address,
            coverLetter,
            firstNiche,
            secondNiche,
            thirdNiche
        }
    } = req;
    const newUserData = {
        name,
        email,
        phone,
        address,
        coverLetter,
        niches:{
            firstNiche,
            secondNiche,
            thirdNiche
        }
    };

    if(req.user.role === "Job Seeker" && (!firstNiche || !secondNiche || !thirdNiche)){
        return next(new ErrorHandler("Please provied your all prefered niches", 400))
    };

    if(req.files){
        const {resume} = req.files;
        if(resume){
            const currentResumeId = req.user.resume.public_id;
            if(currentResumeId){
                await cloudinary.uploader.destroy(currentResumeId)
            };
            const newResume = await cloudinary.uploader.upload(resume.tempFilePath,{
                folder:"Job_Seeker_Resume"
            });

            if(!newResume || newResume.error){
                return next( new ErrorHandler("Failed to upload resume to cloud", 500));
            };

            newUserData.resume = {
                public_id: newResume.public_id,
                url: newResume.secure_url,
            }
        }
    };

    const user = await User.findByIdAndUpdate(req.user.id,newUserData,{
        new: true,
        runValidators: true,
        useFindAndModify: false
    });

    res.status(200).json({
        success: true,
        user,
        message:"Profile updated."
    })
});

export const updatePassword = catchAsyncErrors(async (req, res, next) => {
    const user = await User.findById(req.user.id).select("+password");
    console.log(req.body.oldPassword);
    const isPasswordMatched = await user.comparedPassword(req.body.oldPassword);
    console.log(isPasswordMatched);
    if(!isPasswordMatched){
        return next(new ErrorHandler("Old password is incorrect.", 400));
    };

    if(req.body.newPassword !== req.body.confirmPassword){
        return next(new ErrorHandler("New Password & Confirm Password do not matched.", 400));
    };

    user.password = req.body.newPassword;
    console.log(user.password);
    await user.save();
    console.log(user);
    sendToken(user, 200, res, "Password updated successfully.")
});