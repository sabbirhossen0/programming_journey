import mongoose from "mongoose";

export const connection = () => {
    mongoose.connect(process.env.MONGODB_CONNECT,{
        dbName:"Job_Portal"
    })
                        .then(() => console.log("connected..."))
                        .catch(err => console.log(err));
}