import Hero from "../components/Hero"
import TopNiches from "../components/TopNiches"
import How_it_works from "../components/How_it_works"

const Home = () => {
  return (
    <>
      <Hero />
      <TopNiches />
      <How_it_works />
    </>
  )
}

export default Home