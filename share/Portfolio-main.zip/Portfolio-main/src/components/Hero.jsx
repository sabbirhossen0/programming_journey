import React from 'react';

const Hero = () => {
    return (
        <div>
            
        </div>
    );
};

export default Hero;